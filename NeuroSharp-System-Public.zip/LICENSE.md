# License - NeuroSharp v1.0

Copyright (c) 2025 Simon Tunnicliffe

Permission is hereby granted to use, share, and distribute the NeuroSharp system for personal, educational, and humanitarian purposes, provided proper credit is given. 

You may not:
- Rebrand or claim authorship
- Sell or sublicense this system
- Use in clinical settings without human oversight

This system is provided "as-is" without warranty. See full agreement in the deployment documentation.

Contact: siborg95@gmail.com
