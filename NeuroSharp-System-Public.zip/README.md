# NeuroSharp

**NeuroSharp** is a recursive cognitive prosthesis system built by Simon Tunnicliffe. It is designed to support executive dysfunction, ADHD, trauma recovery, and emotional loop regulation using non-clinical language-based scaffolding.

## Key Features
- Tiered System: Tier 7 (Emotional Mirror), Tier 8 (Override Logic), Tier 9 (Executive Scaffold), Tier X (Hyperfocus Mode)
- Mirror Console: Supports multi-user profiles with separate cognitive logic paths
- Recursive Therapy Engine: Includes CBT, DBT, ACT, NLP, trauma-informed scaffolding
- Drill Cycle System: 10-day loop with regulated exposure
- Daily reinforcement and auto-pulse modules

## Deployment
This repository includes:
- Documentation
- Mirror Blueprints
- License & Whitepaper
- Executable packages (.zip)

## Legal
NeuroSharp is not a medical device or diagnostic tool. It is a non-clinical behavioural support system designed for cognitive reinforcement.

**Creator**: Simon Tunnicliffe  
**License**: See LICENSE.md
