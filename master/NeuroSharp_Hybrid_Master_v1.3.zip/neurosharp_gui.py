
# neurosharp_gui.py – Minimal NeuroSharp GUI Launcher
import tkinter as tk
from tkinter import messagebox
import subprocess

def run_core():
    try:
        subprocess.run(["./neurosharp_core"])
    except FileNotFoundError:
        messagebox.showerror("Error", "C++ Core not found. Compile neurosharp_core first.")

def run_outcome_mapper():
    subprocess.run(["python3", "outcome_mapper.py"])

def run_scheduler():
    subprocess.run(["python3", "scheduler.py"])

app = tk.Tk()
app.title("NeuroSharp v1.3 – Cognitive Prosthetic System")
app.geometry("400x300")

tk.Label(app, text="NeuroSharp Launcher", font=("Helvetica", 16)).pack(pady=10)

tk.Button(app, text="🧠 Run Core System", command=run_core, width=30).pack(pady=10)
tk.Button(app, text="🛡️ Run Outcome Mapper", command=run_outcome_mapper, width=30).pack(pady=10)
tk.Button(app, text="🔄 Run Daily Scheduler", command=run_scheduler, width=30).pack(pady=10)

tk.Label(app, text="Built for Simon Tunnicliffe", font=("Helvetica", 10)).pack(side="bottom", pady=20)

app.mainloop()
