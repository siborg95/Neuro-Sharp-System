
# neurosharp_launcher.py – Python shell for calling C++ NeuroSharp system
import os
import subprocess

def run_neurosharp():
    cpp_exe = "./neurosharp_core"  # This assumes compiled C++ output
    json_file = "NeuroSharp_Rebuildmaster_FULL.json"

    print("🔁 Launching NeuroSharp C++ core...")
    if not os.path.exists(json_file):
        print("❌ JSON config not found.")
        return

    if os.path.exists(cpp_exe):
        subprocess.run([cpp_exe])
    else:
        print("⚠️ C++ executable not found. Compile NeuroSharp_Hybrid_v1.cpp first.")

if __name__ == "__main__":
    run_neurosharp()
