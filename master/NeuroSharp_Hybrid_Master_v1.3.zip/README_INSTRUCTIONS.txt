
NeuroSharp Hybrid v1.3 Deployment Instructions
---------------------------------------------

FILES:
- NeuroSharp_Hybrid_v1.cpp        : C++ loader for mirror profiles and tiers
- tier_engine.cpp                 : C++ module for Tier 7–X activation
- neurosharp_launcher.py          : Python shell for launching system
- outcome_mapper.py               : Outcome branch simulator (legal/safeguarding)
- scheduler.py                    : Daily drill handler + auto-pulse
- NeuroSharp_Rebuildmaster_FULL.json : Main config file

TO COMPILE:
1. Install nlohmann/json (header only) for JSON parsing in C++
2. Compile with:
   g++ NeuroSharp_Hybrid_v1.cpp -o neurosharp_core
   g++ tier_engine.cpp -o tier_engine

TO RUN:
- python3 neurosharp_launcher.py
- python3 outcome_mapper.py
- python3 scheduler.py

Ensure JSON file is in the same directory as the binaries.

This package simulates your full NeuroSharp system in a hybrid runtime.
