
# outcome_mapper.py – Legal & Safeguarding Outcome Mapping (NeuroSharp)
def map_outcome(event):
    if event == "return_to_mum":
        return {
            "legal": "CAFCASS re-escalation, court likely",
            "psych": "Anxiety spike, trauma loop",
            "risk_rating": "HIGH"
        }
    elif event == "stay_with_father":
        return {
            "legal": "Strengthened case",
            "psych": "Stability maintained",
            "risk_rating": "LOW"
        }
    else:
        return {
            "message": "Unknown event"
        }
