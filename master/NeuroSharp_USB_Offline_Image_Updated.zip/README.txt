NeuroSharp USB Image - Offline AI Prosthesis System
Owner: Simon Tunnicliffe
Use only under explicit configuration.
